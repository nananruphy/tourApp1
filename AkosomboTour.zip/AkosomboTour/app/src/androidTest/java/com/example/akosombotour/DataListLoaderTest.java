package com.example.akosombotour;

import junit.framework.TestCase;

public class DataListLoaderTest extends TestCase {

}