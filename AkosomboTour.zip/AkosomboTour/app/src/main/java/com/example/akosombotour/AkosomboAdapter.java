package com.example.akosombotour;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class AkosomboAdapter extends ArrayAdapter<Akosombo> {
    public AkosomboAdapter(EthnicgroupsFragment context, ArrayList<Akosombo> akosombo) {
        super(context, 0, akosombo);

    }
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Check if an existing view is being reused, otherwise inflate the view
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(getContext()).inflate(
                    R.layout.list_item, parent, false);
        }

        Akosombo currentAkosombo = getItem(position);


        // Find the TextView in the list_item.xml layout with the ID miwok_text_view.
        TextView miwokTextView = (TextView) listItemView.findViewById(R.id.akosombotour_text_view);
        // Get the Miwok translation from the currentWord object and set this text on
        // the Miwok TextView.
        miwokTextView.setText(currentAkosombo.getakosombo_items());
        return listItemView;
    }

}
