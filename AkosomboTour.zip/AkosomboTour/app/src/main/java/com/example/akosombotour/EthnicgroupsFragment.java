package com.example.akosombotour;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class EthnicgroupsFragment extends Fragment {


    //String[] ethnicgroupsFragment = {"ETHNIC GROUPS","Ewe 45.8%)","Adangbe (28.1%)","Akan (11.6%)","","RELIGION","Christianity (89%)", "Islamic (3.7%)", "Traditionalist (2.4%) "};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        // Create a list of words
        final ArrayList<Akosombo> akosombo = new ArrayList<Akosombo>();
        akosombo.add(new Akosombo("Where are you going?"));
        akosombo.add(new Akosombo("Where are you going?"));
        akosombo.add(new Akosombo("Where are you going?"));
        akosombo.add(new Akosombo("Where are you going?"));
        akosombo.add(new Akosombo("Where are you going?"));
        akosombo.add(new Akosombo("Where are you going?"));


    }
}


