package com.example.akosombotour;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class ToursitesFragment extends Fragment {
    ListView listView;
    ArrayAdapter<String> arrayAdapter;
    private Bitmap mImage1;

    String[] toursites = {"Akosombo Dam","Adomi Bridge","Akosombo Textiles","Akosombo Farms","Akosombo InternationalSchools"};

    public ToursitesFragment(){
        //constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.toursites,container,false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);



        listView = view.findViewById(R.id.listView);

        arrayAdapter = new ArrayAdapter<>(getActivity(),android.R.layout.simple_list_item_1,toursites);

        //setting ArrayAdapter on listView
        listView.setAdapter(arrayAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                if (i == 0) {
                    Intent intent = new Intent(getActivity(), TourImages.class);
                    startActivity(intent);
                }
                if (i == 1) {
                    Intent intent = new Intent(getActivity(), TourImages1.class);
                    startActivity(intent);
                }
                if (i == 2) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 3) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 4) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }
                if (i == 5) {
                    Toast.makeText(getActivity(), "udacity project ", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

}








